package com.esprit.ms.candidat;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RequestMapping("/candidats")
@RestController
public class CandidatRestAPI {

    /*
     final sur les champs injectés via le constructeur garantit que ces
      dépendances ne peuvent pas être modifiées après leur initialisation.
     */
    private final CandidatService candidatService;

    /*
    permet à Spring de gérer et d'injecter automatiquement les dépendances
     d'une classe. Cela signifie que Spring va fournir une instance de
      JobConsumer à la classe CandidateController sans que vous ayez à instancier manuellement cet objet.
     */
    @Autowired
    public CandidatRestAPI(CandidatService candidatService) {
        this.candidatService = candidatService;
    }
    private String title="Hello, i'm the 5SE MS";

     @RequestMapping("/hello")
    public String sayHello(){
        System.out.println(title);
        return  title;
    }

    @GetMapping
    public List<Candidat> getAllCandids() {
        return candidatService.getAllCandidats();
    }

    @GetMapping("/favorites")
    public List<JobDTO> getFavoriteJobs() {
        return candidatService.getFavoriteJobs();
    }
}
