package com.esprit.ms.candidat;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    @Bean
    public Queue jobQueue() {

        // Queue durable pour éviter la perte de messages après redémarrage de RabbitMQ
        //Comme ton cas d’usage concerne la gestion de jobs favoris, perdre des messages n’est pas acceptable (un étudiant pourrait rater un job dans sa liste si RabbitMQ redémarre !).
        return new Queue("jobQueue", false);

    }

    // Nom de la queue (identique à JobMS)
    public static final String CANDID_JOB_QUEUE = "jobQueue";


    // Converter JSON <-> POJO pour que Spring transforme automatiquement les messages
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    // Factory utilisée par @RabbitListener pour utiliser le converter
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory cf, MessageConverter converter) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(cf);
        factory.setMessageConverter(converter);
        // réglages pédagogiques
        factory.setConcurrentConsumers(1);
        factory.setMaxConcurrentConsumers(3);
        return factory;
    }
}
