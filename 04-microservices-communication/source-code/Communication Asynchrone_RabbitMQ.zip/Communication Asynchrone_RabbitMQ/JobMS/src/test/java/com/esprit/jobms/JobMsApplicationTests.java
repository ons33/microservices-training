package com.esprit.jobms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobMsApplicationTests {

    @Test
    void contextLoads() {
    }

}
