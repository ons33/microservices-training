package com.esprit.jobms;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Getter
@Setter
public class Job {


    @Id
    @GeneratedValue
    private  int id;

    @NonNull
    private String service;

    @NonNull
    private boolean etat;

}
