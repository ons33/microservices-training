package com.esprit.jobms;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class JobService {
    private final JobRepository jobRepository;
    private final JobProducer jobProducer;
    private static final Logger log = LoggerFactory.getLogger(JobService.class);


    public JobService(JobRepository jobRepository, JobProducer jobProducer) {
        this.jobRepository = jobRepository;
        this.jobProducer = jobProducer;
    }

    // Sauvegarde d'un Job dans la base de données et envoi à RabbitMQ

    //ici on sauvegarde puis on envoie.
    //si save en base réussit mais l’envoi échoue, on aura un enregistrement sans message.
    @Transactional
    public Job saveAndSendJob(Job jobEntity) {
        Job savedJob = jobRepository.save(jobEntity);
        log.info("Job sauvegardé en base : {}", savedJob.getService());

        // Construire un DTO à envoyer
        JobDTO jobDTO = new JobDTO(savedJob.getId(), savedJob.getService(), savedJob.isEtat());

        // Envoi asynchrone via RabbitMQ
        jobProducer.sendJob(jobDTO);

        return savedJob;
    }

    public Optional<Job> getJobById(int id) {
        return jobRepository.findById(id);
    }

    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

}
