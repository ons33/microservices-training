package com.esprit.jobms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class JobMsApplication {

    public static void main(String[] args) {
        SpringApplication.run(JobMsApplication.class, args);
    }

    @Autowired
    private JobRepository repository;
    @Bean
    ApplicationRunner init() {
        return (args) -> {
            // save
            repository.save(new Job("Service Financier", true));
            repository.save(new Job("Service Info", false));
            // fetch
            repository.findAll().forEach(System.out::println);
        };
    }

}
